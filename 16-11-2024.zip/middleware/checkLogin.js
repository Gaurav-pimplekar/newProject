import jwt from "jsonwebtoken";

const isLoginPerson = async (req, res)=>{
  try {
    const token = req
    
  } catch (error) {
    console.log(error);
  }
}
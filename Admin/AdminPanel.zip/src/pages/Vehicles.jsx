import React, { useEffect, useState } from 'react';
import '../styles/Vehicles.css'; // Optional: Import CSS for styling
import { useDispatch, useSelector } from 'react-redux';
import { getVehicles } from '../storage/adminStorage';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Import useNavigate from react-router-dom

const CabList = () => {
  const [searchTerm, setSearchTerm] = useState(''); // State for search input
  const state = useSelector(state => state.admin); // Getting vehicles from Redux state
  const dispatch = useDispatch();
  const navigate = useNavigate(); // Use navigate hook for programmatic navigation

  // Function to handle search input changes
  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value); // Update searchTerm with user input
  };

  // Function to blacklist a cab
  const handleBlacklist = async (id) => {
    try {
      const res = await axios.patch(`http://localhost:8080/addVehicleToBlockList/${id}`);
      // After blacklisting, update the vehicle list
      dispatch(getVehicles());
    } catch (error) {
      console.log(error);
      alert(error.response.data.message);
    }
  };

  // Function to handle document selection change
  const handleDocumentChange = (id, documentType) => {
    // Handle the document change based on the id of the vehicle and selected document type
    console.log(`Document for Vehicle ${id}: ${documentType}`);
    // Here, you can handle your logic for updating the document
    // For example, you might want to send this information to the backend or update the Redux state
  };

  // Filter cabs based on searchTerm
  const filteredCabs = state?.vehicles?.filter(cab =>
    cab.vehicle_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cab.vehicle_category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cab.brand.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Navigate to the blacklisted cabs page
  const showBlacklisted = () => {
    navigate('/blacklistedcab'); // Navigate to the blacklisted cabs page
  };

  useEffect(() => {
    dispatch(getVehicles());
  }, [dispatch]);

  const handleEditVehicle = (id) => {
    navigate(`/edit-vehicle/${id}`);
  };

  return (
    <div className="cablist">
      <div className="title">
        <h2>Cab List</h2>
      </div>

      {/* Search Bar */}
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search by Vehicle No, Brand or Category"
          value={searchTerm}
          onChange={handleSearchChange} // Update searchTerm on input change
        />
      </div>

      {/* Button to navigate to the Blacklisted Vehicles page */}
      <button className="blacklist" onClick={showBlacklisted}>
        Blacklisted Vehicles
      </button>

      {/* Main Vehicles Table */}
      <table className="cablisttable">
        <thead>
          <tr>
            <th>#</th>
            <th>Vehicle No</th>
            <th>Category</th>
            <th>Brand</th>
            <th>Model Type</th>
            <th>Fuel Type</th>
            <th>Vehicle Ownership</th>
            <th>Registration Date</th>
            <th>Insurance Valid Up To</th>
            <th>Documents</th> {/* New column for documents */}
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredCabs?.map((cab, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>{cab.vehicle_number}</td>
              <td>{cab.vehicle_category}</td>
              <td>{cab.brand}</td>
              <td>{cab.model_type}</td>
              <td>{cab.fuel_type}</td>
              <td>{cab.vehicle_ownership}</td>
              <td>{cab.registration_date}</td>
              <td>{cab.insurance_valid}</td>
              <td>
                <select
                  onChange={(e) => handleDocumentChange(cab._id, e.target.value)}
                >
                  <option value="">Select Document</option>
                  <option value="driver_photo">Insurance Copy</option>
                  <option value="license_front_photo">Registration Format</option>
                  <option value="license_back_photo">Registration Certificate Front</option>
                  <option value="id_proof_front_photo">Registration Certificate Back</option>
                  <option value="id_proof_back_photo">Car Number Photo</option>
                </select>
                </td>
                <td>
                <button className="editbtn" onClick={() => handleEditVehicle(cab._id)}>
                  Edit
                </button>
                <button className="blacklistbtn" onClick={() => handleBlacklist(cab._id)}>
                  Blacklist
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CabList;
